export interface ServiceError {
  message: string
}
