export interface EventHandler {
  setupSubscriptions(): void
}
