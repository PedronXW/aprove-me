import { MailService } from '@/infra/mail/mail-service'
import { Injectable } from '@nestjs/common'
import { BrokerRepository } from '../../broker/broker-repository'

export type BatchCreationRequest = {
  payables?: Array<{
    value?: number
    emissionDate?: Date
  }>
  assignorId: string
}

@Injectable()
export class BatchCreationService {
  constructor(
    private brokerRepository: BrokerRepository,
    private mailService: MailService,
  ) {}

  async execute({ payables, assignorId }: BatchCreationRequest): Promise<void> {
    let counter = 0
    for (const payable of payables) {
      const result = await this.brokerRepository.sendMessage(
        JSON.stringify({ ...payable, assignorId }),
      )
      if (result === false) {
        counter++
      }
    }
    this.mailService.execute({
      mailType: 'QUEUE_RESULT',
      to: 'operationteam@aprove.me',
      text: 'QUEUE_RESULT - ' + counter + ' messages failed to be sent',
    })
  }
}
