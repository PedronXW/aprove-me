export abstract class BrokerRepository {
  abstract sendMessage(message: string): Promise<boolean>
}
