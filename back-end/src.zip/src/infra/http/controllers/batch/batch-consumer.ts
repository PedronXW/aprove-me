import { CreatePayableService } from '@/domain/application/services/payable/create-payable'
import { Controller } from '@nestjs/common'
import { Ctx, MessagePattern, Payload, RmqContext } from '@nestjs/microservices'

@Controller()
export class BatchConsumerController {
  constructor(private createPayableService: CreatePayableService) {}

  @MessagePattern('QUEUE')
  public async execute(@Payload() payload: string, @Ctx() context: RmqContext) {
    if(payload.package)
    const channel = context.getChannelRef()
    const originalMsg = context.getMessage()
    const data = JSON.parse(payload)
    await this.createPayableService.execute(data)
    channel.ack(originalMsg)
  }
}
