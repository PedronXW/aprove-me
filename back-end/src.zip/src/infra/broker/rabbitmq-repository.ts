import { BrokerRepository } from '@/domain/application/broker/broker-repository'
import { Inject, Injectable } from '@nestjs/common'
import { ClientProxy } from '@nestjs/microservices'
import { MailService } from '../mail/mail-service'

@Injectable()
export class RabbitmqRepository implements BrokerRepository {
  constructor(
    @Inject('QUEUE') private queue: ClientProxy,
    private mailService: MailService,
  ) {}

  async sendMessage(message: string): Promise<boolean> {
    try {
      await this.queue.connect()
    } catch (error) {
      return false
    }
    for (let attempts = 0; attempts < 5; attempts++) {
      try {
        this.queue.emit('QUEUE', message)
        return true
      } catch (error) {
        if (attempts === 4) {
          this.queue.emit('DEAD_QUEUE', message)
          this.mailService.execute({
            mailType: 'QUEUE_FAILURE',
            to: 'operationteam@aprove.me',
            text: 'QUEUE_FAILURE - ' + message + ' - ' + error.message,
          })
          return false
        }
      }
    }
    return true
  }
}
