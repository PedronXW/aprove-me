import { BrokerRepository } from '@/domain/application/broker/broker-repository'
import { Module } from '@nestjs/common'
import { ClientsModule, Transport } from '@nestjs/microservices'
import { MailModule } from '../mail/mail.module'
import { RabbitmqRepository } from './rabbitmq-repository'

@Module({
  imports: [
    ClientsModule.register([
      {
        name: 'QUEUE',
        transport: Transport.RMQ,
        options: {
          urls: ['amqp://guest:guest@rabbitmq:5672'],
          queue: 'QUEUE',
          queueOptions: {
            durable: false,
          },
        },
      },
      {
        name: 'DEAD_QUEUE',
        transport: Transport.RMQ,
        options: {
          urls: ['amqp://guest:guest@rabbitmq:5672'],
          queue: 'DEAD_QUEUE',
          queueOptions: {
            durable: false,
          },
        },
      },
    ]),
    MailModule,
  ],
  providers: [
    {
      provide: BrokerRepository,
      useClass: RabbitmqRepository,
    },
  ],
  exports: [BrokerRepository],
})
export class BrokerModule {}
